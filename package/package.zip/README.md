# Exchange Changes

A mod to simply change the time exchange interactions happen, letting you have faster printers, faster scrappers, and faster shrines of chance!
Supports configuration support for every interaction.

## Changelog

**1.0.0**

* First release of the mod

**1.0.1**

* Actually works now, didn't notice I uploaded a broken version :)

**1.0.2**

* Added support for the shrine of chance

**1.0.3**

* Fixed not allowing clients without the mod to connect

**1.0.4**

* Added support for the Lunar cauldrons

**1.0.5**

* Fixed Printer eating items without returning any when used constantly

**1.0.6**

* Dont output debug directly to the chat, thats bad :)

**1.0.7**

* Fixed Lunar Cauldrons handing out two items for every purchase

**1.0.8**

* Added Support for Cleansing Pools

**1.0.9**

* Updated mod to support latest version

**1.0.10**

* Fixed not allowing clients without the mod to connect, again

**1.1.0**

* Added support for riskofoptions ingame, and fixed timing issues with various objects

**1.1.1**

* Fixed missing riskofoptions dependency

**1.1.2**

* Added support for Shrine of the Woods and Shrines of blood, and updated dependencies
